* Tripwire 2.4.2.2 Policy Generator README

This readme is a quick guide on something introduced in this version 
of Tripwire: the Policy Generator. The idea behind is to generate a 
custom file fitting your system. 

It has so far been tested on Debian Wheezy and CentOS 5.7/6.0, your 
mileage may vary. 

This is not part of the standard install so you will have to do this 
manually for now if you want to use it. 

This is also provided as-is but if you happen to find out bugs, have 
improvement suggestions or patches, send them to: tripwire@frlinux.net

