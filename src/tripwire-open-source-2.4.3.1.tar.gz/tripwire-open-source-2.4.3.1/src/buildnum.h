#define BUILD_NUM _T("0")

