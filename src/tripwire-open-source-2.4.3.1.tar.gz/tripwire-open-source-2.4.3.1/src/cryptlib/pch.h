#ifndef PCH_H
#define PCH_H

#include "config.h"

#ifdef USE_PRECOMPILED_HEADERS
#include "cryptlib.h"
#include "misc.h"
#include "smartptr.h"
/*
#include <utility>
#include <algorithm>
#include <vector>
#include <iostream>
*/
#endif

#endif
