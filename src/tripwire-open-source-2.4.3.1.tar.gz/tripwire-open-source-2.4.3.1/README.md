#Open Source Tripwire<sup>®</sup> 

Open Source Tripwire<sup>®</sup> software is a security and data integrity tool useful for monitoring and alerting on specific file change(s) on a range of systems. The project is based on code originally contributed by [Tripwire, Inc.](http://www.tripwire.com) in 2000.

Open Source Tripwire is suitable for monitoring a small number of Linux servers, where centralized control and reporting is not needed and professional support or system automation is not a requirement. 
